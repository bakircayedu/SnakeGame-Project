#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <conio.h>
#include <time.h>

#define food '+'
#define wall '#'
#define space ' '
#define left '<'
#define right '>'
#define up 'A'
#define down 'V'
#define deadhead 'X'
#define uniformbody 1
#define body 'O'
#define xmax 34
#define ymax 20
#define maxsnake (xmax-2)*(ymax-2)
#define tickfreq 40
#define startstepfreq 300
#define stepfreqlimit 200
#define ESCAPE 27
#define SPACE ' '
//Ay�e Nur DURMAZ-210601693

int running = 1;

int stepfreq, nexttick, nextstep;

char field[xmax][ymax];

int x_head, y_head, x_tail, y_tail;
char head;
char dir;

int grow, ssize, points;

int i, o, x, y;
char buf[(xmax + 1) * (ymax + 1)];
int cbuf;

struct Oyuncu_kayit {
    char  oyuncu_Ad[50];
    int skor;

};
struct Oyuncu_kayit oyncu1;


int main()
{
    //Ba�lang�� Sayfas�
    printf("...::: SNAKE GAME WITH C :::...\n");
    printf("Kontroller: W/A/S/D  \n");
    oyncu1.skor = points;
    printf("SKORUNU KAYDETMEK ���N B�LG�LER�N�Z� G�R�N�Z...\n");
    printf("Kullan�c� Ad�: ");
    scanf("%s", oyncu1.oyuncu_Ad);
    printf("Skorunuz Kaydedildi..");

    FILE* pdosya;
    pdosya = fopen("Skorlar.txt", "a");
    fprintf(pdosya, "%s%s%s", "\n", oyncu1.oyuncu_Ad, " ");
    fprintf(pdosya, "%d%s", oyncu1.skor, "\n");

    fclose(pdosya);
    srand(time(NULL));

    printf("\n   Ba�lamak i�in bir tu�a bas�n !");
    getch();

    while (42) //program loop
    {


        for (x = 0; x < xmax; x++) for (y = 0; y < ymax; y++)
        {
            field[x][y] = (x == 0 || y == 0 || x == xmax - 1 || y == ymax - 1) ? wall : space;
        } //engeller
        field[5][5] = food;
        field[1][3] = field[2][3] = field[3][3] = 'r';
        x_head = 3; y_head = 3;
        x_tail = 1; y_tail = 3;
        dir = head = 'r';
        grow = 0;
        ssize = 3;
        points = 0;

        stepfreq = startstepfreq;
        nexttick = GetTickCount();
        nextstep = GetTickCount() + stepfreq;

        while (running) //oyun d�ng�s�
        {
            if (kbhit())
            {
                char key = getch();
                if (dir != 'r' && key == 'a') head = 'l';
                if (dir != 'l' && key == 'd') head = 'r';
                if (dir != 'd' && key == 'w') head = 'u';
                if (dir != 'u' && key == 's') head = 'd';
                if (key == ESCAPE) return 0;
            }
            field[x_head][y_head] = head;

            //hareket
            if (GetTickCount() >= nextstep)
            {
                nextstep += stepfreq;

                dir = head;
                if (dir == 'l') x_head--;
                if (dir == 'r') x_head++;
                if (dir == 'u') y_head--;
                if (dir == 'd') y_head++;

                if (grow) grow--;
                else
                {
                    char tail = field[x_tail][y_tail];
                    field[x_tail][y_tail] = space;
                    if (tail == 'l') x_tail--;
                    if (tail == 'r') x_tail++;
                    if (tail == 'u') y_tail--;
                    if (tail == 'd') y_tail++;
                }

                if (field[x_head][y_head] == food) //yem bulundu�unda
                {
                    ssize += (grow += 2);
                    points += ssize * 10;
                    if (stepfreq > stepfreqlimit) stepfreq--;

                    if (ssize >= maxsnake)
                    {
                        printf("(: Kazand�n�z ! :)"); return 0;
                    }

                    i = rand() % maxsnake;
                    while (1)
                    {
                        x = i % (xmax - 2) + 1;
                        y = (int)i / (xmax - 2) + 1;
                        if (field[x][y] == space) break;
                        else { i--; if (i < 0) i += maxsnake; }
                    }
                    field[x][y] = food;
                }

                if (field[x_head][y_head] != space && field[x_head][y_head] != food)
                {
                    field[x_head][y_head] = deadhead;
                    running = 0;
                }
                else field[x_head][y_head] = head;

            }


            cbuf = 0;
            for (y = 0; y < ymax; y++)
            {
                for (x = 0; x < xmax; x++)
                {

                    o = field[x][y];
                    i = 0;
                    if (o == 'l') { o = left;  i++; }
                    if (o == 'r') { o = right; i++; }
                    if (o == 'u') { o = up;    i++; }
                    if (o == 'd') { o = down;  i++; }
                    if (i && uniformbody && !(x_head == x && y_head == y)) o = body;
                    buf[cbuf++] = o;
                }
                buf[cbuf++] = '\n';
            }
            buf[cbuf++] = '\0';

            while (GetTickCount() == nexttick) {}
            nexttick += tickfreq;
            system("cls");
            printf("SNAKE               points %07d\n%s", points, buf);
        }

        printf("GAME OVER! - TRY AGAIN [SPACE]");
        while (1) { i = getch(); if (i == SPACE) break; else if (i == ESCAPE) return 0; }
        running = 1;
    }
}

